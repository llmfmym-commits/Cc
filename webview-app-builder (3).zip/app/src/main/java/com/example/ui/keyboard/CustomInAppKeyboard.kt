package com.example.ui.keyboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.KeyboardReturn
import androidx.compose.material.icons.filled.KeyboardHide
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class KeyboardMode {
    PERSIAN,
    ENGLISH,
    FRENCH,
    SYMBOLS,
    EMOJI
}

/**
 * Modular In-App Keyboard supporting Persian, English, French (Français), Numbers, Symbols, and Emojis.
 */
@Composable
fun CustomInAppKeyboard(
    onCharTyped: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit,
    onDismiss: () -> Unit,
    initialLanguage: String = "AUTO",
    modifier: Modifier = Modifier
) {
    var mode by remember {
        mutableStateOf(
            when (initialLanguage.uppercase()) {
                "FR" -> KeyboardMode.FRENCH
                "EN" -> KeyboardMode.ENGLISH
                else -> KeyboardMode.PERSIAN
            }
        )
    }
    var isShifted by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF1E293B)),
        color = Color(0xFF1E293B),
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp)
        ) {
            // Header bar: mode indicator, quick numbers, hide button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick suggestions
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val quickChars = when (mode) {
                        KeyboardMode.PERSIAN -> listOf("۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۰", "؟", "،")
                        KeyboardMode.FRENCH -> listOf("é", "è", "à", "ç", "ù", "ê", "â", "ô", "î", "1", "2", "3")
                        else -> listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "@", ".com")
                    }
                    quickChars.forEach { ch ->
                        KeyButton(
                            text = ch,
                            onClick = { onCharTyped(ch) },
                            modifier = Modifier.width(36.dp),
                            backgroundColor = Color(0xFF334155),
                            textColor = Color.White
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardHide,
                        contentDescription = "Hide Keyboard",
                        tint = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            when (mode) {
                KeyboardMode.PERSIAN -> {
                    PersianKeyboardLayout(
                        onChar = onCharTyped,
                        onBackspace = onBackspace,
                        onEnter = onEnter,
                        onSpace = { onCharTyped(" ") }
                    )
                }
                KeyboardMode.ENGLISH -> {
                    EnglishKeyboardLayout(
                        isShifted = isShifted,
                        onToggleShift = { isShifted = !isShifted },
                        onChar = {
                            onCharTyped(it)
                            if (isShifted) isShifted = false
                        },
                        onBackspace = onBackspace,
                        onEnter = onEnter,
                        onSpace = { onCharTyped(" ") }
                    )
                }
                KeyboardMode.FRENCH -> {
                    FrenchKeyboardLayout(
                        isShifted = isShifted,
                        onToggleShift = { isShifted = !isShifted },
                        onChar = {
                            onCharTyped(it)
                            if (isShifted) isShifted = false
                        },
                        onBackspace = onBackspace,
                        onEnter = onEnter,
                        onSpace = { onCharTyped(" ") }
                    )
                }
                KeyboardMode.SYMBOLS -> {
                    SymbolsKeyboardLayout(
                        onChar = onCharTyped,
                        onBackspace = onBackspace,
                        onEnter = onEnter,
                        onSpace = { onCharTyped(" ") }
                    )
                }
                KeyboardMode.EMOJI -> {
                    EmojiKeyboardLayout(
                        onEmoji = onCharTyped,
                        onBackspace = onBackspace
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Bottom control row: Language & Mode switchers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val langLabel = when (mode) {
                    KeyboardMode.PERSIAN -> "فا"
                    KeyboardMode.ENGLISH -> "EN"
                    KeyboardMode.FRENCH -> "FR"
                    else -> "فا"
                }

                KeyButton(
                    text = langLabel,
                    onClick = {
                        mode = when (mode) {
                            KeyboardMode.PERSIAN -> KeyboardMode.ENGLISH
                            KeyboardMode.ENGLISH -> KeyboardMode.FRENCH
                            KeyboardMode.FRENCH -> KeyboardMode.PERSIAN
                            else -> KeyboardMode.PERSIAN
                        }
                    },
                    modifier = Modifier.weight(1.2f),
                    backgroundColor = Color(0xFF3B82F6),
                    textColor = Color.White
                )

                KeyButton(
                    text = if (mode == KeyboardMode.SYMBOLS) "ABC" else "?123",
                    onClick = {
                        mode = if (mode == KeyboardMode.SYMBOLS) KeyboardMode.PERSIAN else KeyboardMode.SYMBOLS
                    },
                    modifier = Modifier.weight(1.2f),
                    backgroundColor = Color(0xFF475569),
                    textColor = Color.White
                )

                KeyButton(
                    text = if (mode == KeyboardMode.EMOJI) "ABC" else "😀",
                    onClick = {
                        mode = if (mode == KeyboardMode.EMOJI) KeyboardMode.PERSIAN else KeyboardMode.EMOJI
                    },
                    modifier = Modifier.weight(1f),
                    backgroundColor = Color(0xFF475569),
                    textColor = Color.White
                )

                // Large Space Bar
                Box(
                    modifier = Modifier
                        .weight(3.5f)
                        .height(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF334155))
                        .clickable { onCharTyped(" ") },
                    contentAlignment = Alignment.Center
                ) {
                    val spaceLabel = when (mode) {
                        KeyboardMode.PERSIAN -> "فاصله"
                        KeyboardMode.FRENCH -> "Espace"
                        else -> "Space"
                    }
                    Text(spaceLabel, color = Color(0xFF94A3B8), fontSize = 13.sp)
                }

                // Enter Key
                Box(
                    modifier = Modifier
                        .weight(1.5f)
                        .height(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF10B981))
                        .clickable { onEnter() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardReturn,
                        contentDescription = "Enter",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PersianKeyboardLayout(
    onChar: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit,
    onSpace: () -> Unit
) {
    val row1 = listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ")
    val row2 = listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ")
    val row3 = listOf("ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و")

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        KeyboardRow(row1, onChar)
        KeyboardRow(row2, onChar)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            row3.forEach { ch ->
                KeyButton(
                    text = ch,
                    onClick = { onChar(ch) },
                    modifier = Modifier.weight(1f)
                )
            }
            // Backspace key
            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF475569))
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun EnglishKeyboardLayout(
    isShifted: Boolean,
    onToggleShift: () -> Unit,
    onChar: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit,
    onSpace: () -> Unit
) {
    val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
    val row3 = listOf("z", "x", "c", "v", "b", "n", "m")

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        KeyboardRow(row1.map { if (isShifted) it.uppercase() else it }, onChar)
        KeyboardRow(row2.map { if (isShifted) it.uppercase() else it }, onChar)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            KeyButton(
                text = "⇧",
                onClick = onToggleShift,
                modifier = Modifier.weight(1.3f),
                backgroundColor = if (isShifted) Color(0xFF3B82F6) else Color(0xFF475569),
                textColor = Color.White
            )

            row3.forEach { ch ->
                val display = if (isShifted) ch.uppercase() else ch
                KeyButton(
                    text = display,
                    onClick = { onChar(display) },
                    modifier = Modifier.weight(1f)
                )
            }

            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF475569))
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun FrenchKeyboardLayout(
    isShifted: Boolean,
    onToggleShift: () -> Unit,
    onChar: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit,
    onSpace: () -> Unit
) {
    // AZERTY layout for French
    val row1 = listOf("a", "z", "e", "r", "t", "y", "u", "i", "o", "p")
    val row2 = listOf("q", "s", "d", "f", "g", "h", "j", "k", "l", "m")
    val row3 = listOf("w", "x", "c", "v", "b", "n", "é", "è", "à", "ç")

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        KeyboardRow(row1.map { if (isShifted) it.uppercase() else it }, onChar)
        KeyboardRow(row2.map { if (isShifted) it.uppercase() else it }, onChar)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            KeyButton(
                text = "⇧",
                onClick = onToggleShift,
                modifier = Modifier.weight(1.2f),
                backgroundColor = if (isShifted) Color(0xFF3B82F6) else Color(0xFF475569),
                textColor = Color.White
            )

            row3.forEach { ch ->
                val display = if (isShifted) ch.uppercase() else ch
                KeyButton(
                    text = display,
                    onClick = { onChar(display) },
                    modifier = Modifier.weight(1f)
                )
            }

            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF475569))
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun SymbolsKeyboardLayout(
    onChar: (String) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit,
    onSpace: () -> Unit
) {
    val row1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val row2 = listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/")
    val row3 = listOf("*", "\"", "'", ":", ";", "!", "?", "_", "~")

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        KeyboardRow(row1, onChar)
        KeyboardRow(row2, onChar)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            row3.forEach { ch ->
                KeyButton(
                    text = ch,
                    onClick = { onChar(ch) },
                    modifier = Modifier.weight(1f)
                )
            }

            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF475569))
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun EmojiKeyboardLayout(
    onEmoji: (String) -> Unit,
    onBackspace: () -> Unit
) {
    val emojis = listOf(
        "😀", "😂", "🥰", "😎", "🤔", "👍", "❤️", "🔥", "🎉", "✨",
        "👏", "🙏", "💪", "🚀", "💡", "⭐", "🇮🇷", "🇫🇷", "🇺🇸", "🌐"
    )

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            emojis.take(10).forEach { emoji ->
                KeyButton(text = emoji, onClick = { onEmoji(emoji) }, modifier = Modifier.weight(1f))
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            emojis.drop(10).take(9).forEach { emoji ->
                KeyButton(text = emoji, onClick = { onEmoji(emoji) }, modifier = Modifier.weight(1f))
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF475569))
                    .clickable { onBackspace() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun KeyboardRow(
    keys: List<String>,
    onChar: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        keys.forEach { key ->
            KeyButton(
                text = key,
                onClick = { onChar(key) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun KeyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    backgroundColor: Color = Color(0xFF334155),
    textColor: Color = Color.White
) {
    Box(
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
