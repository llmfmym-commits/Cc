package com.example.ui.apkbuilder

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.apkbuilder.ApkBuildConfig
import com.example.data.apkbuilder.BuildEngineMode
import com.example.data.apkbuilder.BuildProgress
import com.example.data.apkbuilder.BuildResult
import com.example.data.apkbuilder.ReleaseKeystoreConfig
import com.example.data.apkbuilder.ScreenOrientationOption
import com.example.data.apkbuilder.SigningType
import com.example.data.model.WebAppItem
import com.example.ui.launcher.BrandAppIcon
import com.example.viewmodel.AppViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkBuilderScreen(
    appViewModel: AppViewModel,
    builderViewModel: ApkBuilderViewModel,
    onBack: () -> Unit,
    initialWebApp: WebAppItem? = null
) {
    val context = LocalContext.current
    val allWebApps by appViewModel.allApps.collectAsState()
    val selectedWebApp by builderViewModel.selectedWebApp.collectAsState()
    val buildConfig by builderViewModel.buildConfig.collectAsState()
    val currentStep by builderViewModel.currentStep.collectAsState()
    val buildProgress by builderViewModel.buildProgress.collectAsState()
    val buildResult by builderViewModel.buildResult.collectAsState()
    val buildHistory by builderViewModel.buildHistory.collectAsState()

    // Preselect webapp if provided
    remember(initialWebApp) {
        if (initialWebApp != null && selectedWebApp == null) {
            builderViewModel.selectWebApp(initialWebApp)
        }
        true
    }

    val stepTitles = listOf(
        "انتخاب وب‌اپ",
        "مشخصات برنامه",
        "آیکون و ظاهر",
        "دسترسی‌ها و چرخش",
        "امضا و موتور بیلد",
        "بیلد و خروجی"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "سازنده APK (تبدیل Web App به APK)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "گام ${currentStep + 1} از 6: ${stepTitles.getOrElse(currentStep) { "" }}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    IconButton(onClick = { builderViewModel.reset() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "شروع مجدد")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Step Progress Bar
            LinearProgressIndicator(
                progress = { (currentStep + 1) / 6f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = Color(0xFF38BDF8),
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            // Step Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (currentStep) {
                    0 -> StepSelectWebApp(
                        allWebApps = allWebApps,
                        selectedApp = selectedWebApp,
                        onSelect = { app -> builderViewModel.selectWebApp(app) }
                    )
                    1 -> StepAppDetails(
                        config = buildConfig,
                        onUpdate = { transform -> builderViewModel.updateConfig(transform) }
                    )
                    2 -> StepAppIcon(
                        config = buildConfig,
                        onUpdate = { transform -> builderViewModel.updateConfig(transform) }
                    )
                    3 -> StepPermissionsAndDisplay(
                        config = buildConfig,
                        onUpdate = { transform -> builderViewModel.updateConfig(transform) }
                    )
                    4 -> StepEngineAndSigning(
                        config = buildConfig,
                        onUpdate = { transform -> builderViewModel.updateConfig(transform) }
                    )
                    5 -> StepBuildProgressAndResult(
                        progress = buildProgress,
                        result = buildResult,
                        history = buildHistory,
                        onStartBuild = { builderViewModel.startBuild() },
                        onInstall = { file -> builderViewModel.installApk(context, file) },
                        onShare = { file -> builderViewModel.shareApk(context, file) },
                        onSave = { file -> builderViewModel.saveApkToDownloads(context, file) },
                        onShareZip = { file -> builderViewModel.shareProjectZip(context, file) }
                    )
                }
            }

            // Bottom Navigation Controls
            BottomActionBar(
                currentStep = currentStep,
                canProceed = when (currentStep) {
                    0 -> selectedWebApp != null
                    1 -> buildConfig.appName.isNotBlank() && buildConfig.packageName.isNotBlank()
                    else -> true
                },
                onPrev = { builderViewModel.prevStep() },
                onNext = {
                    if (currentStep == 4) {
                        builderViewModel.startBuild()
                    } else {
                        builderViewModel.nextStep()
                    }
                }
            )
        }
    }
}

@Composable
fun StepSelectWebApp(
    allWebApps: List<WebAppItem>,
    selectedApp: WebAppItem?,
    onSelect: (WebAppItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "یک برنامه وب موجود (آدرس اینترنتی، صفحه HTML یا پکیج ZIP) را برای تبدیل به یک فایل APK مستقل انتخاب کنید.",
                        fontSize = 13.sp,
                        color = Color(0xFFE2E8F0),
                        lineHeight = 20.sp
                    )
                }
            }
        }

        if (allWebApps.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "هنوز هیچ برنامه وبی اضافه نشده است. ابتدا یک برنامه در صفحه اصلی ایجاد کنید.",
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(allWebApps) { app ->
                val isSelected = selectedApp?.id == app.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(app) }
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155),
                            shape = RoundedCornerShape(16.dp)
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF0F172A) else Color(0xFF1E293B)
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BrandAppIcon(
                            app = app,
                            size = 46.dp,
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = app.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = when (app.type) {
                                    "LOCAL_HTML" -> "صفحه HTML آفلاین"
                                    "LOCAL_ZIP" -> "پروژه ZIP آفلاین"
                                    else -> app.targetUrl
                                },
                                fontSize = 12.sp,
                                color = Color(0xFF94A3B8),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (isSelected) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StepAppDetails(
    config: ApkBuildConfig,
    onUpdate: ((ApkBuildConfig) -> ApkBuildConfig) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "مشخصات پکیج و نام برنامه در اندروید",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        OutlinedTextField(
            value = config.appName,
            onValueChange = { onUpdate { prev -> prev.copy(appName = it) } },
            label = { Text("نام برنامه (App Name)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        OutlinedTextField(
            value = config.packageName,
            onValueChange = { onUpdate { prev -> prev.copy(packageName = it) } },
            label = { Text("شناسه پکیج (Package Name / ApplicationId)") },
            supportingText = { Text("فرمت استاندارد مانند: com.company.myapp") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = config.versionName,
                onValueChange = { onUpdate { prev -> prev.copy(versionName = it) } },
                label = { Text("نام نسخه (Version Name)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            OutlinedTextField(
                value = config.versionCode.toString(),
                onValueChange = {
                    val code = it.toIntOrNull() ?: 1
                    onUpdate { prev -> prev.copy(versionCode = code) }
                },
                label = { Text("کد نسخه (Version Code)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "نکته درباره Package Name:",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = Color(0xFF38BDF8)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "شناسه پکیج هویت منحصربه‌فرد برنامه در سیستم‌عامل اندروید است. برای نصب بدون تداخل، از شناسه‌ای یکتا استفاده کنید.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun StepAppIcon(
    config: ApkBuildConfig,
    onUpdate: ((ApkBuildConfig) -> ApkBuildConfig) -> Unit
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            onUpdate { prev -> prev.copy(appIconUri = uri.toString()) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "آیکون برنامه در لانچر اندروید",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp
        )

        // Icon Preview Card
        Card(
            modifier = Modifier.size(120.dp),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color(config.appIconColor ?: 0xFF3B82F6))
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = config.appName.take(1).uppercase(),
                    color = Color.White,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Text(
            text = "پیش‌نمایش آیکون: ${config.appName}",
            fontSize = 13.sp,
            color = Color.Gray
        )

        Button(
            onClick = { photoPickerLauncher.launch("image/*") },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8))
        ) {
            Icon(Icons.Default.Image, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("انتخاب تصویر دلخواه از گالری", color = Color(0xFF0F172A))
        }

        if (!config.appIconUri.isNullOrBlank()) {
            OutlinedButton(
                onClick = { onUpdate { prev -> prev.copy(appIconUri = null) } }
            ) {
                Text("حذف تصویر اختصاصی (استفاده از آیکون تمپلیت)")
            }
        }
    }
}

@Composable
fun StepPermissionsAndDisplay(
    config: ApkBuildConfig,
    onUpdate: ((ApkBuildConfig) -> ApkBuildConfig) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "جهت صفحه (Screen Orientation)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        items(ScreenOrientationOption.values()) { option ->
            val isSelected = config.orientation == option
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onUpdate { prev -> prev.copy(orientation = option) } },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { onUpdate { prev -> prev.copy(orientation = option) } }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(option.displayNameFa, fontSize = 13.sp)
                }
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
            Text(
                text = "دسترسی‌های سخت‌افزاری و وب (Permissions)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        item {
            PermissionToggleItem(
                title = "دوربین (Camera)",
                description = "جهت عکس‌برداری یا تماس تصویری داخل وب‌اپ",
                checked = config.permissions.camera,
                onCheckedChange = { v ->
                    onUpdate { prev -> prev.copy(permissions = prev.permissions.copy(camera = v)) }
                }
            )
        }

        item {
            PermissionToggleItem(
                title = "میکروفون (Microphone)",
                description = "جهت ضبط صوت و ارتباط صوتی تحت وب",
                checked = config.permissions.microphone,
                onCheckedChange = { v ->
                    onUpdate { prev -> prev.copy(permissions = prev.permissions.copy(microphone = v)) }
                }
            )
        }

        item {
            PermissionToggleItem(
                title = "موقعیت مکانی (Location)",
                description = "جهت ارائه موقعیت کاربر به سایت‌های نیازمند GPS",
                checked = config.permissions.location,
                onCheckedChange = { v ->
                    onUpdate { prev -> prev.copy(permissions = prev.permissions.copy(location = v)) }
                }
            )
        }

        item {
            PermissionToggleItem(
                title = "حافظه و ذخیره‌سازی (Storage)",
                description = "دسترسی دانلود و ذخیره فایل در حافظه",
                checked = config.permissions.storage,
                onCheckedChange = { v ->
                    onUpdate { prev -> prev.copy(permissions = prev.permissions.copy(storage = v)) }
                }
            )
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
            Text(
                text = "تنظیمات وب‌ویو (WebView Options)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        item {
            PermissionToggleItem(
                title = "کشیدن به پایین برای تازه‌سازی (Pull to Refresh)",
                description = "امکان بارگذاری مجدد صفحه با کشیدن به پایین",
                checked = config.pullToRefresh,
                onCheckedChange = { v -> onUpdate { prev -> prev.copy(pullToRefresh = v) } }
            )
        }

        item {
            PermissionToggleItem(
                title = "پاک‌سازی کش و کوکی هنگام خروج",
                description = "افزایش حریم خصوصی و امنیت اطلاعات",
                checked = config.clearCacheOnExit,
                onCheckedChange = { v -> onUpdate { prev -> prev.copy(clearCacheOnExit = v) } }
            )
        }
    }
}

@Composable
fun PermissionToggleItem(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(description, fontSize = 11.sp, color = Color.Gray)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

@Composable
fun StepEngineAndSigning(
    config: ApkBuildConfig,
    onUpdate: ((ApkBuildConfig) -> ApkBuildConfig) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "موتور بیلد (Build Engine Architecture)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        // Technical Analysis Card (Honest analysis as requested)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بررسی واقع‌بینانه بیلد محلی در اندروید:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF38BDF8)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "اجرای کامل کامپایلر Gradle، Java 17 و Android SDK Platform روی پردازنده گوشی نیازمند چند گیگابایت حافظه و پیش‌نیازهای روت/ترمینال است. به همین دلیل معماری دوگانه طراحی شده است: حالت RemoteBuildEngine (بیلد سبک و ابری) و حالت LocalBuildEngine (آماده‌سازی کامل سورس جهت بیلد).",
                        fontSize = 11.sp,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        items(BuildEngineMode.values()) { mode ->
            val isSelected = config.buildEngineMode == mode
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onUpdate { prev -> prev.copy(buildEngineMode = mode) } },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) Color(0xFF1E293B) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(12.dp),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF38BDF8)) else null
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { onUpdate { prev -> prev.copy(buildEngineMode = mode) } }
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(mode.titleFa, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(mode.descriptionFa, fontSize = 11.sp, color = Color.Gray, lineHeight = 16.sp)
                    }
                }
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
            Text(
                text = "امضای دیجیتال (Signing Key)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        }

        items(SigningType.values()) { st ->
            val isSelected = config.signingType == st
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onUpdate { prev -> prev.copy(signingType = st) } },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) Color(0xFF1E293B) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { onUpdate { prev -> prev.copy(signingType = st) } }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(st.titleFa, fontSize = 13.sp)
                }
            }
        }

        if (config.signingType == SigningType.RELEASE) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("تنظیمات Release Keystore", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        OutlinedTextField(
                            value = config.releaseKeystore?.keyAlias ?: "",
                            onValueChange = { alias ->
                                onUpdate { prev ->
                                    val rk = (prev.releaseKeystore ?: ReleaseKeystoreConfig()).copy(keyAlias = alias)
                                    prev.copy(releaseKeystore = rk)
                                }
                            },
                            label = { Text("Key Alias") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = config.releaseKeystore?.storePassword ?: "",
                            onValueChange = { pass ->
                                onUpdate { prev ->
                                    val rk = (prev.releaseKeystore ?: ReleaseKeystoreConfig()).copy(storePassword = pass)
                                    prev.copy(releaseKeystore = rk)
                                }
                            },
                            label = { Text("Keystore Password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StepBuildProgressAndResult(
    progress: BuildProgress,
    result: BuildResult?,
    history: List<File>,
    onStartBuild: () -> Unit,
    onInstall: (File) -> Unit,
    onShare: (File) -> Unit,
    onSave: (File) -> Unit,
    onShareZip: (File) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        when (progress) {
            is BuildProgress.Idle -> {
                item {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            Icons.Default.Build,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "همه چیز برای ساخت بستهٔ APK آماده است.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "برای شروع فرآیند استخراج قالب، اعمال تنظیمات و ساخت APK دکمه زیر را فشار دهید.",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onStartBuild,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8))
                        ) {
                            Text("شروع تبدیل به APK", color = Color(0xFF0F172A), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            is BuildProgress.Preparing,
            is BuildProgress.Extracting,
            is BuildProgress.Configuring,
            is BuildProgress.Building,
            is BuildProgress.Signing -> {
                item {
                    BuildStepperCard(progress)
                }
            }

            is BuildProgress.Completed -> {
                item {
                    BuildSuccessCard(
                        completed = progress,
                        onInstall = { onInstall(progress.apkFile) },
                        onShare = { onShare(progress.apkFile) },
                        onSave = { onSave(progress.apkFile) },
                        onShareZip = { progress.projectZipFile?.let { onShareZip(it) } }
                    )
                }
            }

            is BuildProgress.Failed -> {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = Color.Red, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("خطا در فرآیند بیلد", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(progress.error, fontSize = 13.sp, color = Color(0xFFFECACA), textAlign = TextAlign.Center)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = onStartBuild, colors = ButtonDefaults.buttonColors(containerColor = Color.White)) {
                                Text("تلاش مجدد", color = Color.Black)
                            }
                        }
                    }
                }
            }
        }

        // Previous Builds History
        if (history.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تاریخچه فایل‌های APK ساخته‌شده:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            items(history) { apk ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Android, contentDescription = null, tint = Color(0xFF34D399), modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(apk.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                            Text("${apk.length() / 1024} KB", fontSize = 11.sp, color = Color.Gray)
                        }
                        IconButton(onClick = { onInstall(apk) }) {
                            Icon(Icons.Default.Download, contentDescription = "نصب", tint = Color(0xFF38BDF8))
                        }
                        IconButton(onClick = { onShare(apk) }) {
                            Icon(Icons.Default.Share, contentDescription = "اشتراک", tint = Color(0xFFE2E8F0))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BuildStepperCard(progress: BuildProgress) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(
                color = Color(0xFF38BDF8),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))

            val currentMsg = when (progress) {
                is BuildProgress.Preparing -> progress.message
                is BuildProgress.Extracting -> progress.message
                is BuildProgress.Configuring -> progress.message
                is BuildProgress.Building -> progress.message
                is BuildProgress.Signing -> progress.message
                else -> "در حال پردازش..."
            }
            Text(
                text = currentMsg,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Visual Progress Steps
            StepItemIndicator(title = "۱. آماده‌سازی محیط بیلد (Preparing)", active = progress is BuildProgress.Preparing || progress is BuildProgress.Extracting || progress is BuildProgress.Configuring || progress is BuildProgress.Building || progress is BuildProgress.Signing)
            StepItemIndicator(title = "۲. استخراج قالب apk-template.zip (Extracting)", active = progress is BuildProgress.Extracting || progress is BuildProgress.Configuring || progress is BuildProgress.Building || progress is BuildProgress.Signing)
            StepItemIndicator(title = "۳. پیکربندی پکیج و کدهای پروژه (Configuring)", active = progress is BuildProgress.Configuring || progress is BuildProgress.Building || progress is BuildProgress.Signing)
            StepItemIndicator(title = "۴. کامپایل و بیلد بستهٔ APK (Building)", active = progress is BuildProgress.Building || progress is BuildProgress.Signing)
            StepItemIndicator(title = "۵. امضای دیجیتال و تأیید (Signing)", active = progress is BuildProgress.Signing)
        }
    }
}

@Composable
fun StepItemIndicator(title: String, active: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (active) Color(0xFF38BDF8) else Color(0xFF475569))
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            color = if (active) Color.White else Color(0xFF64748B)
        )
    }
}

@Composable
fun BuildSuccessCard(
    completed: BuildProgress.Completed,
    onInstall: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
    onShareZip: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF10B981))
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint = Color(0xFF10B981),
                modifier = Modifier.size(54.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "APK با موفقیت تولید شد!",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = completed.message,
                fontSize = 12.sp,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                color = Color(0xFF1E293B),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("نام برنامه: ${completed.appName}", color = Color.White, fontSize = 13.sp)
                    Text("پکیج: ${completed.packageName}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    Text("نسخه: ${completed.versionName}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    Text("مسیر فایل: ${completed.apkFile.name}", color = Color(0xFF38BDF8), fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            Button(
                onClick = onInstall,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
                Icon(Icons.Default.Android, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("نصب مستقیم APK روی دستگاه", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onShare,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("اشتراک‌گذاری APK", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onSave,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ذخیره در دانلودها", fontSize = 12.sp)
                }
            }

            if (completed.projectZipFile != null) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onShareZip,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("دریافت سورس کامل پروژه اندروید (ZIP)", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun BottomActionBar(
    currentStep: Int,
    canProceed: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (currentStep > 0 && currentStep < 5) {
                OutlinedButton(onClick = onPrev) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مرحله قبل")
                }
            } else {
                Spacer(modifier = Modifier.width(1.dp))
            }

            if (currentStep < 5) {
                Button(
                    onClick = onNext,
                    enabled = canProceed,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (currentStep == 4) Color(0xFF10B981) else Color(0xFF38BDF8)
                    )
                ) {
                    Text(
                        text = if (currentStep == 4) "ساخت و تولید APK" else "مرحله بعد",
                        color = Color(0xFF0F172A),
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFF0F172A)
                    )
                }
            }
        }
    }
}
