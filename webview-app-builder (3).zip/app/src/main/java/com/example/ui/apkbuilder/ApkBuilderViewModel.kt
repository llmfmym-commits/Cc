package com.example.ui.apkbuilder

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.apkbuilder.ApkBuildConfig
import com.example.data.apkbuilder.BuildEngine
import com.example.data.apkbuilder.BuildEngineMode
import com.example.data.apkbuilder.BuildProgress
import com.example.data.apkbuilder.BuildResult
import com.example.data.apkbuilder.LocalBuildEngine
import com.example.data.apkbuilder.RemoteBuildEngine
import com.example.data.apkbuilder.TemplateProjectManager
import com.example.data.model.WebAppItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream

class ApkBuilderViewModel(application: Application) : AndroidViewModel(application) {

    private val templateManager = TemplateProjectManager(application)

    private val _selectedWebApp = MutableStateFlow<WebAppItem?>(null)
    val selectedWebApp: StateFlow<WebAppItem?> = _selectedWebApp.asStateFlow()

    private val _buildConfig = MutableStateFlow(ApkBuildConfig())
    val buildConfig: StateFlow<ApkBuildConfig> = _buildConfig.asStateFlow()

    private val _currentStep = MutableStateFlow(0)
    val currentStep: StateFlow<Int> = _currentStep.asStateFlow()

    private val _buildProgress = MutableStateFlow<BuildProgress>(BuildProgress.Idle)
    val buildProgress: StateFlow<BuildProgress> = _buildProgress.asStateFlow()

    private val _buildResult = MutableStateFlow<BuildResult?>(null)
    val buildResult: StateFlow<BuildResult?> = _buildResult.asStateFlow()

    private val _buildHistory = MutableStateFlow<List<File>>(emptyList())
    val buildHistory: StateFlow<List<File>> = _buildHistory.asStateFlow()

    init {
        loadHistory()
    }

    fun selectWebApp(webApp: WebAppItem) {
        _selectedWebApp.value = webApp
        val rawPackage = webApp.name.lowercase().replace(Regex("[^a-z0-9]"), "")
        val safePackage = if (rawPackage.isBlank()) "app" else rawPackage
        _buildConfig.value = _buildConfig.value.copy(
            webappId = webApp.id,
            appName = webApp.name,
            packageName = "com.webapp.$safePackage",
            versionCode = 1,
            versionName = "1.0.0",
            appIconColor = null,
            appIconName = webApp.iconPreset,
            appIconUri = webApp.iconPath
        )
        _currentStep.value = 1
    }

    fun updateConfig(transform: (ApkBuildConfig) -> ApkBuildConfig) {
        _buildConfig.value = transform(_buildConfig.value)
    }

    fun goToStep(step: Int) {
        _currentStep.value = step.coerceIn(0, 5)
    }

    fun nextStep() {
        _currentStep.value = (_currentStep.value + 1).coerceAtMost(5)
    }

    fun prevStep() {
        _currentStep.value = (_currentStep.value - 1).coerceAtLeast(0)
    }

    fun startBuild() {
        val webApp = _selectedWebApp.value ?: return
        val config = _buildConfig.value
        _currentStep.value = 4 // Build Progress Step
        _buildProgress.value = BuildProgress.Preparing("شروع فرآیند تبدیل به APK...")

        viewModelScope.launch {
            val engine: BuildEngine = when (config.buildEngineMode) {
                BuildEngineMode.LOCAL_PREPARATION -> LocalBuildEngine(getApplication(), templateManager, webApp)
                BuildEngineMode.REMOTE_SERVER -> RemoteBuildEngine(getApplication(), templateManager, webApp)
            }

            val result = engine.executeBuild(config) { progress ->
                _buildProgress.value = progress
            }
            _buildResult.value = result
            if (result.success) {
                _currentStep.value = 5 // Results Step
                loadHistory()
            }
        }
    }

    fun reset() {
        _selectedWebApp.value = null
        _buildConfig.value = ApkBuildConfig()
        _currentStep.value = 0
        _buildProgress.value = BuildProgress.Idle
        _buildResult.value = null
    }

    fun loadHistory() {
        val buildsDir = File(getApplication<Application>().filesDir, TemplateProjectManager.BUILDS_DIR_NAME)
        if (buildsDir.exists()) {
            val apks = buildsDir.walkTopDown()
                .filter { it.isFile && it.extension.equals("apk", ignoreCase = true) }
                .sortedByDescending { it.lastModified() }
                .toList()
            _buildHistory.value = apks
        }
    }

    fun installApk(context: Context, apkFile: File) {
        if (!apkFile.exists()) {
            Toast.makeText(context, "فایل APK یافت نشد.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در اجرای نصب: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun shareApk(context: Context, apkFile: File) {
        if (!apkFile.exists()) {
            Toast.makeText(context, "فایل APK یافت نشد.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, apkFile.name)
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری APK"))
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در اشتراک‌گذاری: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareProjectZip(context: Context, zipFile: File) {
        if (!zipFile.exists()) return
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zipFile
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, zipFile.name)
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری سورس پروژه"))
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در اشتراک‌گذاری پروژه: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveApkToDownloads(context: Context, apkFile: File) {
        if (!apkFile.exists()) return

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, apkFile.name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        FileInputStream(apkFile).use { inputStream ->
                            inputStream.copyTo(outputStream)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    Toast.makeText(context, "فایل در پوشه دانلودها ذخیره شد: ${apkFile.name}", Toast.LENGTH_LONG).show()
                }
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val destFile = File(downloadsDir, apkFile.name)
                apkFile.copyTo(destFile, overwrite = true)
                Toast.makeText(context, "فایل ذخیره شد: ${destFile.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "خطا در ذخیره فایل: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
