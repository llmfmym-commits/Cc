package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.WebAppItem
import com.example.ui.apkbuilder.ApkBuilderScreen
import com.example.ui.apkbuilder.ApkBuilderViewModel
import com.example.ui.browser.BookmarksScreen
import com.example.ui.browser.TabsScreen
import com.example.ui.browser.WebViewScreen
import com.example.ui.launcher.AddAppScreen
import com.example.ui.launcher.AppearanceCustomizationScreen
import com.example.ui.launcher.HomeScreen
import com.example.ui.launcher.HtmlBuilderScreen
import com.example.ui.launcher.PinLockDialog
import com.example.ui.launcher.WallpaperScreen
import com.example.ui.launcher.WebViewSettingsScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.AppStrings
import com.example.util.LocalAppStrings
import com.example.viewmodel.AppViewModel
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val appViewModel: AppViewModel = viewModel()
            val settings by appViewModel.settings.collectAsState()

            val isDarkTheme = when (settings.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            val currentStrings = AppStrings.get(settings.language)
            val isRtl = when (settings.language) {
                "FA" -> true
                "EN", "FR" -> false
                else -> Locale.getDefault().language == "fa" || Locale.getDefault().language == "ar"
            }
            val layoutDirection = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(
                LocalAppStrings provides currentStrings,
                LocalLayoutDirection provides layoutDirection
            ) {
                MyApplicationTheme(darkTheme = isDarkTheme) {
                    MainAppNavHost(appViewModel)
                }
            }
        }
    }
}

enum class ScreenState {
    HOME,
    SETTINGS,
    ADD_APP,
    BROWSER,
    TABS,
    BOOKMARKS,
    WALLPAPER,
    HTML_BUILDER,
    WEBVIEW_SETTINGS,
    APPEARANCE,
    APK_BUILDER
}

@Composable
fun MainAppNavHost(viewModel: AppViewModel) {
    val apkBuilderViewModel: ApkBuilderViewModel = viewModel()
    val settings by viewModel.settings.collectAsState()
    val tabs by viewModel.tabs.collectAsState()
    var currentScreen by remember { mutableStateOf(ScreenState.HOME) }
    var activeWebApp by remember { mutableStateOf<WebAppItem?>(null) }

    // Master PIN lock gate on startup if enabled
    var isMasterUnlocked by remember { mutableStateOf(!settings.appLockEnabled) }

    // Android back navigation handler
    if (currentScreen != ScreenState.HOME) {
        BackHandler {
            currentScreen = ScreenState.HOME
        }
    }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (currentScreen) {
                ScreenState.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onOpenApp = { app ->
                            activeWebApp = app
                            currentScreen = ScreenState.BROWSER
                        },
                        onOpenSettings = {
                            currentScreen = ScreenState.SETTINGS
                        },
                        onOpenHtmlBuilder = {
                            currentScreen = ScreenState.HTML_BUILDER
                        },
                        onOpenAddApp = {
                            currentScreen = ScreenState.ADD_APP
                        },
                        onOpenWallpaper = {
                            currentScreen = ScreenState.WALLPAPER
                        },
                        onOpenTabs = {
                            currentScreen = ScreenState.TABS
                        },
                        onOpenBookmarks = {
                            currentScreen = ScreenState.BOOKMARKS
                        },
                        onOpenWebViewSettings = {
                            currentScreen = ScreenState.WEBVIEW_SETTINGS
                        },
                        onOpenAppearance = {
                            currentScreen = ScreenState.APPEARANCE
                        },
                        onConvertToApk = { app ->
                            activeWebApp = app
                            apkBuilderViewModel.selectWebApp(app)
                            currentScreen = ScreenState.APK_BUILDER
                        }
                    )
                }

                ScreenState.SETTINGS -> {
                    SettingsScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = ScreenState.HOME },
                        onNavigateToAppearance = { currentScreen = ScreenState.APPEARANCE },
                        onNavigateToWallpaper = { currentScreen = ScreenState.WALLPAPER },
                        onNavigateToTabs = { currentScreen = ScreenState.TABS },
                        onNavigateToBookmarks = { currentScreen = ScreenState.BOOKMARKS },
                        onNavigateToHtmlBuilder = { currentScreen = ScreenState.HTML_BUILDER },
                        onNavigateToAddApp = { currentScreen = ScreenState.ADD_APP },
                        onNavigateToApkBuilder = {
                            currentScreen = ScreenState.APK_BUILDER
                        },
                        onOpenUrlInBrowser = { url ->
                            activeWebApp = WebAppItem(
                                name = "Web",
                                type = "WEB_URL",
                                targetUrl = url
                            )
                            currentScreen = ScreenState.BROWSER
                        }
                    )
                }

                ScreenState.ADD_APP -> {
                    AddAppScreen(
                        onBack = { currentScreen = ScreenState.HOME },
                        onAppCreated = { name, type, targetUrl, iconPath ->
                            viewModel.addWebApp(
                                name = name,
                                type = type,
                                targetUrl = targetUrl,
                                iconPath = iconPath
                            )
                        }
                    )
                }

                ScreenState.BROWSER -> {
                    activeWebApp?.let { appItem ->
                        WebViewScreen(
                            appItem = appItem,
                            viewModel = viewModel,
                            onCloseBrowser = {
                                currentScreen = ScreenState.HOME
                                activeWebApp = null
                            },
                            onOpenTabs = {
                                currentScreen = ScreenState.TABS
                            },
                            onOpenBookmarks = {
                                currentScreen = ScreenState.BOOKMARKS
                            },
                            tabsCount = tabs.size.coerceAtLeast(1)
                        )
                    } ?: run {
                        currentScreen = ScreenState.HOME
                    }
                }

                ScreenState.TABS -> {
                    TabsScreen(
                        viewModel = viewModel,
                        onBack = {
                            if (activeWebApp != null) {
                                currentScreen = ScreenState.BROWSER
                            } else {
                                currentScreen = ScreenState.HOME
                            }
                        },
                        onSelectTab = { tab ->
                            activeWebApp = WebAppItem(
                                name = tab.title,
                                type = "WEB_URL",
                                targetUrl = tab.url
                            )
                            currentScreen = ScreenState.BROWSER
                        },
                        onAddNewTab = {
                            currentScreen = ScreenState.ADD_APP
                        }
                    )
                }

                ScreenState.BOOKMARKS -> {
                    BookmarksScreen(
                        viewModel = viewModel,
                        onBack = {
                            if (activeWebApp != null) {
                                currentScreen = ScreenState.BROWSER
                            } else {
                                currentScreen = ScreenState.HOME
                            }
                        },
                        onOpenUrl = { title, url ->
                            activeWebApp = WebAppItem(
                                name = title,
                                type = "WEB_URL",
                                targetUrl = url
                            )
                            currentScreen = ScreenState.BROWSER
                        }
                    )
                }

                ScreenState.WALLPAPER -> {
                    WallpaperScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = ScreenState.HOME }
                    )
                }

                ScreenState.HTML_BUILDER -> {
                    HtmlBuilderScreen(
                        onBack = { currentScreen = ScreenState.HOME },
                        onSaveApp = { name, targetUrl, iconPath ->
                            viewModel.addWebApp(
                                name = name,
                                type = "HTML",
                                targetUrl = targetUrl,
                                iconPath = iconPath
                            )
                        }
                    )
                }

                ScreenState.WEBVIEW_SETTINGS -> {
                    WebViewSettingsScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = ScreenState.HOME }
                    )
                }

                ScreenState.APPEARANCE -> {
                    AppearanceCustomizationScreen(
                        viewModel = viewModel,
                        onBack = { currentScreen = ScreenState.HOME }
                    )
                }

                ScreenState.APK_BUILDER -> {
                    ApkBuilderScreen(
                        appViewModel = viewModel,
                        builderViewModel = apkBuilderViewModel,
                        onBack = { currentScreen = ScreenState.HOME },
                        initialWebApp = activeWebApp
                    )
                }
            }

            // Master App Lock Dialog
            if (settings.appLockEnabled && !isMasterUnlocked && settings.masterPin.isNotEmpty()) {
                PinLockDialog(
                    correctPin = settings.masterPin,
                    title = "ورود به WebView App Builder",
                    onUnlocked = { isMasterUnlocked = true },
                    onDismiss = { /* Keep locked */ }
                )
            }
        }
    }
}
