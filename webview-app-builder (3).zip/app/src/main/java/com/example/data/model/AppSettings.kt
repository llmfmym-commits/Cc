package com.example.data.model

data class AppSettings(
    val wallpaperType: String = "DEFAULT", // "DEFAULT", "COLOR", "GRADIENT", "IMAGE", "NONE"
    val wallpaperValue: String = "DEFAULT", // Color hex, gradient key, or image file path
    val panelOpacity: Float = 0.70f, // 0.0f to 1.0f (slider in Wallpaper screen)
    val themeMode: String = "DARK", // "SYSTEM", "LIGHT", "DARK"
    val columnCount: Int = 4, // 3, 4, 5
    val iconSize: String = "MEDIUM", // "SMALL", "MEDIUM", "LARGE"
    val iconShape: String = "SQUIRCLE", // "ROUNDED_SQUARE", "CIRCLE", "SQUIRCLE", "SQUARE"
    val accentColorHex: String = "#3B82F6",
    val appLockEnabled: Boolean = false,
    val masterPin: String = "",
    val sortMode: String = "MANUAL",
    val jsEnabledGlobal: Boolean = true,
    val cookiesEnabledGlobal: Boolean = true,
    val localStorageEnabledGlobal: Boolean = true,
    val zoomEnabledGlobal: Boolean = false,
    val desktopModeGlobal: Boolean = false,
    val incognitoGlobal: Boolean = false,
    val userAgentGlobal: String = "Mobile",
    val language: String = "SYSTEM", // "SYSTEM", "FA", "EN", "FR"
    val keyboardType: String = "SYSTEM", // "SYSTEM", "APP"
    val keyboardLanguage: String = "AUTO", // "AUTO", "FA", "EN", "FR"
    val defaultSearchEngine: String = "https://www.google.com/search?q=",
    val homePage: String = "https://www.google.com"
)
