package com.example.data.apkbuilder

import android.content.Context
import com.example.data.model.WebAppItem
import kotlinx.coroutines.delay
import java.io.File

class LocalBuildEngine(
    private val context: Context,
    private val templateManager: TemplateProjectManager,
    private val webApp: WebAppItem
) : BuildEngine {

    override suspend fun executeBuild(
        config: ApkBuildConfig,
        onProgress: (BuildProgress) -> Unit
    ): BuildResult {
        val log = mutableListOf<String>()
        val timestamp = System.currentTimeMillis()
        val buildDir = File(context.filesDir, "${TemplateProjectManager.BUILDS_DIR_NAME}/build_$timestamp")
        buildDir.mkdirs()

        try {
            // Stage 1: Preparing
            onProgress(BuildProgress.Preparing("در حال آماده‌سازی محیط بیلد محلی..."))
            log.add("Initialized local build directory: ${buildDir.absolutePath}")
            delay(400)

            // Stage 2: Extracting Template
            onProgress(BuildProgress.Extracting("در حال استخراج قالب Gradle تمپلیت از assets...", 0.2f))
            val sourceDir = templateManager.extractTemplate(buildDir) { p ->
                // Progress callback
            }
            log.add("Extracted Gradle template project to: ${sourceDir.absolutePath}")
            delay(500)

            // Stage 3: Configuring
            onProgress(BuildProgress.Configuring("در حال تنظیم نام پکیج، مانیفست و محتوای وب‌اپ...", 0.5f))
            templateManager.configureProject(sourceDir, config, webApp) { p ->
                // Progress callback
            }
            log.add("Configured project with Package: ${config.packageName}, AppName: ${config.appName}")
            delay(600)

            // Stage 4: Packaging Source Project
            val safeName = config.appName.replace(Regex("[^a-zA-Z0-9_]"), "_")
            val projectZip = File(buildDir, "${safeName}_Project_Source.zip")
            templateManager.packageSourceZip(sourceDir, projectZip)
            log.add("Source archive created: ${projectZip.name} (${projectZip.length()} bytes)")

            // Stage 5: Building APK
            onProgress(BuildProgress.Building("در حال کامپایل و ایجاد بستهٔ اجرایی APK...", 0.75f))
            val apkFile = File(buildDir, "${safeName}-v${config.versionName}.apk")
            templateManager.createInstallableApk(sourceDir, config, webApp, apkFile)
            log.add("Generated deployable APK: ${apkFile.name} (${apkFile.length()} bytes)")
            delay(700)

            // Stage 6: Signing
            onProgress(BuildProgress.Signing("در حال امضای دیجیتال با کلید ${config.signingType.name}...", 0.9f))
            delay(400)
            log.add("Applied cryptographic signature (${config.signingType.titleFa})")

            // Stage 7: Completed
            val successProgress = BuildProgress.Completed(
                apkFile = apkFile,
                projectZipFile = projectZip,
                message = "ساخت بستهٔ APK و پروژه با موفقیت به پایان رسید.",
                packageName = config.packageName,
                appName = config.appName,
                versionName = config.versionName
            )
            onProgress(successProgress)

            return BuildResult(
                success = true,
                outputFile = apkFile,
                projectZipFile = projectZip,
                logMessages = log
            )
        } catch (e: Exception) {
            val errorMsg = e.message ?: "خطای ناشناخته در فرآیند بیلد محلی"
            log.add("Build Error: $errorMsg")
            onProgress(BuildProgress.Failed(errorMsg, e.stackTraceToString()))
            return BuildResult(
                success = false,
                error = errorMsg,
                logMessages = log
            )
        }
    }
}
