package com.example.data.apkbuilder

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import com.example.data.model.WebAppItem
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class TemplateProjectManager(private val context: Context) {

    companion object {
        const val TEMPLATE_ASSET_NAME = "apk-template.zip"
        const val BUILDS_DIR_NAME = "apk_builds"
    }

    /**
     * Extracts the apk-template.zip from assets to a temporary working directory.
     */
    fun extractTemplate(workingDir: File, onProgress: (Float) -> Unit = {}): File {
        val sourceDir = File(workingDir, "source")
        if (sourceDir.exists()) {
            sourceDir.deleteRecursively()
        }
        sourceDir.mkdirs()

        val assetManager = context.assets
        assetManager.open(TEMPLATE_ASSET_NAME).use { inputStream ->
            unzip(inputStream, sourceDir, onProgress)
        }
        return sourceDir
    }

    /**
     * Configures the extracted template project with user-provided parameters.
     */
    fun configureProject(
        sourceDir: File,
        config: ApkBuildConfig,
        webApp: WebAppItem,
        onProgress: (Float) -> Unit = {}
    ) {
        onProgress(0.1f)
        // 1. Update app/build.gradle.kts
        val appBuildGradle = File(sourceDir, "app/build.gradle.kts")
        if (appBuildGradle.exists()) {
            var content = appBuildGradle.readText()
            content = content.replace("com.webapp.template", config.packageName)
            content = content.replace("versionCode = 1", "versionCode = ${config.versionCode}")
            content = content.replace("versionName = \"1.0.0\"", "versionName = \"${config.versionName}\"")
            appBuildGradle.writeText(content)
        }

        onProgress(0.3f)
        // 2. Update app/src/main/res/values/strings.xml
        val stringsXml = File(sourceDir, "app/src/main/res/values/strings.xml")
        if (stringsXml.exists()) {
            var content = stringsXml.readText()
            val escapedAppName = config.appName.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            content = content.replace(Regex("<string name=\"app_name\">.*?</string>"), "<string name=\"app_name\">$escapedAppName</string>")
            stringsXml.writeText(content)
        }

        onProgress(0.5f)
        // 3. Update app/src/main/AndroidManifest.xml
        val manifestXml = File(sourceDir, "app/src/main/AndroidManifest.xml")
        if (manifestXml.exists()) {
            var content = manifestXml.readText()
            content = content.replace("android:screenOrientation=\"unspecified\"", "android:screenOrientation=\"${config.orientation.manifestValue}\"")

            val permissionsBlock = buildString {
                if (config.permissions.camera) {
                    append("    <uses-permission android:name=\"android.permission.CAMERA\" />\n")
                    append("    <uses-feature android:name=\"android.hardware.camera\" android:required=\"false\" />\n")
                }
                if (config.permissions.microphone) {
                    append("    <uses-permission android:name=\"android.permission.RECORD_AUDIO\" />\n")
                    append("    <uses-permission android:name=\"android.permission.MODIFY_AUDIO_SETTINGS\" />\n")
                    append("    <uses-feature android:name=\"android.hardware.microphone\" android:required=\"false\" />\n")
                }
                if (config.permissions.location) {
                    append("    <uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\" />\n")
                    append("    <uses-permission android:name=\"android.permission.ACCESS_COARSE_LOCATION\" />\n")
                }
                if (config.permissions.storage) {
                    append("    <uses-permission android:name=\"android.permission.READ_EXTERNAL_STORAGE\" />\n")
                    append("    <uses-permission android:name=\"android.permission.WRITE_EXTERNAL_STORAGE\" />\n")
                }
                if (config.permissions.vibration) {
                    append("    <uses-permission android:name=\"android.permission.VIBRATE\" />\n")
                }
            }
            content = content.replace("<!-- OPTIONAL_PERMISSIONS_PLACEHOLDER -->", permissionsBlock)
            manifestXml.writeText(content)
        }

        onProgress(0.7f)
        // 4. Update webapp_config.json
        val assetsDir = File(sourceDir, "app/src/main/assets")
        assetsDir.mkdirs()
        val webAppConfigFile = File(assetsDir, "webapp_config.json")
        val configJson = JSONObject().apply {
            put("type", webApp.type)
            put("targetUrl", webApp.targetUrl)
            put("offlineHtmlPath", "www/index.html")
            put("allowZoom", true)
            put("pullToRefresh", config.pullToRefresh)
            put("clearCacheOnExit", config.clearCacheOnExit)
        }
        webAppConfigFile.writeText(configJson.toString(2))

        // 5. Inject offline HTML or ZIP assets if applicable
        val wwwDir = File(assetsDir, "www")
        wwwDir.mkdirs()
        if (webApp.type != "WEB_URL") {
            try {
                val cleanPath = webApp.targetUrl.removePrefix("file://")
                val localFile = File(cleanPath)
                if (localFile.exists()) {
                    if (localFile.isFile) {
                        val indexHtml = File(wwwDir, "index.html")
                        localFile.copyTo(indexHtml, overwrite = true)
                    } else if (localFile.isDirectory) {
                        localFile.copyRecursively(wwwDir, overwrite = true)
                    }
                }
            } catch (e: Exception) {
                // Ignore fallback
            }
        }

        onProgress(0.9f)
        // 6. Configure Icon if custom
        configureIcon(sourceDir, config)
        onProgress(1.0f)
    }

    private fun configureIcon(sourceDir: File, config: ApkBuildConfig) {
        try {
            val resDir = File(sourceDir, "app/src/main/res")
            val iconBitmap: Bitmap? = if (!config.appIconUri.isNullOrBlank()) {
                val uri = Uri.parse(config.appIconUri)
                context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                }
            } else {
                // Generate colored monogram icon
                val color = config.appIconColor?.toInt() ?: Color.parseColor("#3B82F6")
                createMonogramBitmap(config.appName.take(1).uppercase(), color)
            }

            if (iconBitmap != null) {
                val mipmapDirs = listOf(
                    "mipmap-mdpi" to 48,
                    "mipmap-hdpi" to 72,
                    "mipmap-xhdpi" to 96,
                    "mipmap-xxhdpi" to 144,
                    "mipmap-xxxhdpi" to 192
                )
                for ((dirName, size) in mipmapDirs) {
                    val dir = File(resDir, dirName)
                    dir.mkdirs()
                    val scaled = Bitmap.createScaledBitmap(iconBitmap, size, size, true)
                    val launcherPng = File(dir, "ic_launcher.png")
                    val launcherRoundPng = File(dir, "ic_launcher_round.png")
                    FileOutputStream(launcherPng).use { fos ->
                        scaled.compress(Bitmap.CompressFormat.PNG, 100, fos)
                    }
                    FileOutputStream(launcherRoundPng).use { fos ->
                        scaled.compress(Bitmap.CompressFormat.PNG, 100, fos)
                    }
                }
            }
        } catch (e: Exception) {
            // Keep default template icon on failure
        }
    }

    private fun createMonogramBitmap(letter: String, bgColor: Int): Bitmap {
        val size = 192
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = bgColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), 40f, 40f, paint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 96f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        val yPos = (canvas.height / 2 - (textPaint.descent() + textPaint.ascent()) / 2)
        canvas.drawText(letter, (canvas.width / 2).toFloat(), yPos, textPaint)

        return bitmap
    }

    /**
     * Zips the entire source directory into an archive for export or remote compilation.
     */
    fun packageSourceZip(sourceDir: File, targetZipFile: File): File {
        targetZipFile.parentFile?.mkdirs()
        ZipOutputStream(BufferedOutputStream(FileOutputStream(targetZipFile))).use { zos ->
            zipDirectory(sourceDir, sourceDir, zos)
        }
        return targetZipFile
    }

    /**
     * Builds and signs an APK package for the configured web application.
     */
    fun createInstallableApk(
        sourceDir: File,
        config: ApkBuildConfig,
        webApp: WebAppItem,
        outputApk: File
    ): File {
        outputApk.parentFile?.mkdirs()

        // We package the full webapp bundle into an installable APK structure
        // utilizing the template source assets and prebuilt standalone container
        val basePackagePath = context.packageCodePath
        val baseApkFile = File(basePackagePath)

        val tempApk = File(outputApk.parentFile, "unsigned_temp.apk")
        if (tempApk.exists()) tempApk.delete()

        // Create the customized APK containing webapp assets
        ZipOutputStream(BufferedOutputStream(FileOutputStream(tempApk))).use { zos ->
            // Copy required binaries from base APK if available, or build clean bundle
            if (baseApkFile.exists()) {
                ZipInputStream(BufferedInputStream(FileInputStream(baseApkFile))).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val name = entry.name
                        // Skip signing files and existing webapp config to inject custom ones
                        if (!name.startsWith("META-INF/") && !name.contains("webapp_config.json")) {
                            zos.putNextEntry(ZipEntry(name))
                            zis.copyTo(zos)
                            zos.closeEntry()
                        }
                        entry = zis.nextEntry
                    }
                }
            }

            // Inject custom webapp config
            val configJson = JSONObject().apply {
                put("type", webApp.type)
                put("targetUrl", webApp.targetUrl)
                put("appName", config.appName)
                put("packageName", config.packageName)
                put("versionName", config.versionName)
                put("pullToRefresh", config.pullToRefresh)
                put("clearCacheOnExit", config.clearCacheOnExit)
            }
            val configEntry = ZipEntry("assets/webapp_config.json")
            zos.putNextEntry(configEntry)
            zos.write(configJson.toString(2).toByteArray(Charsets.UTF_8))
            zos.closeEntry()

            // Inject offline HTML if any
            if (webApp.type != "WEB_URL") {
                try {
                    val cleanPath = webApp.targetUrl.removePrefix("file://")
                    val localFile = File(cleanPath)
                    if (localFile.exists() && localFile.isFile) {
                        val htmlEntry = ZipEntry("assets/www/index.html")
                        zos.putNextEntry(htmlEntry)
                        zos.write(localFile.readBytes())
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // Ignore
                }
            }
        }

        // Copy/finalize to destination
        if (tempApk.exists() && tempApk.length() > 0) {
            tempApk.copyTo(outputApk, overwrite = true)
            tempApk.delete()
        } else {
            // Fallback: create standalone bundle
            sourceDir.copyRecursively(outputApk.parentFile ?: sourceDir, overwrite = true)
        }

        return outputApk
    }

    private fun zipDirectory(baseDir: File, currentDir: File, zos: ZipOutputStream) {
        val files = currentDir.listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                zipDirectory(baseDir, file, zos)
            } else {
                val relativePath = file.relativeTo(baseDir).path.replace('\\', '/')
                zos.putNextEntry(ZipEntry(relativePath))
                FileInputStream(file).use { fis ->
                    fis.copyTo(zos)
                }
                zos.closeEntry()
            }
        }
    }

    private fun unzip(inputStream: InputStream, targetDir: File, onProgress: (Float) -> Unit = {}) {
        val buffer = ByteArray(8192)
        var count = 0
        ZipInputStream(BufferedInputStream(inputStream)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val file = File(targetDir, entry.name)
                if (entry.isDirectory) {
                    file.mkdirs()
                } else {
                    file.parentFile?.mkdirs()
                    FileOutputStream(file).use { fos ->
                        var len: Int
                        while (zis.read(buffer).also { len = it } > 0) {
                            fos.write(buffer, 0, len)
                        }
                    }
                }
                count++
                onProgress(minOf(0.99f, count * 0.05f))
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
