package com.example.data.model

data class DownloadItem(
    val id: Long = System.currentTimeMillis(),
    val fileName: String,
    val fileUri: String,
    val mimeType: String = "*/*",
    val timestamp: Long = System.currentTimeMillis()
)
