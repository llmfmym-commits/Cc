package com.example.data.apkbuilder

import android.content.Context
import com.example.data.model.WebAppItem
import kotlinx.coroutines.delay
import java.io.File

class RemoteBuildEngine(
    private val context: Context,
    private val templateManager: TemplateProjectManager,
    private val webApp: WebAppItem
) : BuildEngine {

    override suspend fun executeBuild(
        config: ApkBuildConfig,
        onProgress: (BuildProgress) -> Unit
    ): BuildResult {
        val log = mutableListOf<String>()
        val timestamp = System.currentTimeMillis()
        val buildDir = File(context.filesDir, "${TemplateProjectManager.BUILDS_DIR_NAME}/remote_$timestamp")
        buildDir.mkdirs()

        try {
            // Stage 1: Preparing
            onProgress(BuildProgress.Preparing("آماده‌سازی پکیج پروژه جهت ارسال به سرور بیلد..."))
            log.add("Initialized remote build session: $timestamp")
            delay(350)

            // Stage 2: Extracting Template
            onProgress(BuildProgress.Extracting("استخراج تمپلیت رسمی Gradle از مخزن داخلی...", 0.2f))
            val sourceDir = templateManager.extractTemplate(buildDir)
            log.add("Extracted gradle template to: ${sourceDir.absolutePath}")
            delay(400)

            // Stage 3: Configuring
            onProgress(BuildProgress.Configuring("پیکربندی هویت برنامه، مجوزها و محتوای وب‌اپ...", 0.45f))
            templateManager.configureProject(sourceDir, config, webApp)
            log.add("Configured parameters: id=${config.packageName}, v=${config.versionName}")
            delay(500)

            // Stage 4: Package Project Archive
            val safeName = config.appName.replace(Regex("[^a-zA-Z0-9_]"), "_")
            val projectZip = File(buildDir, "${safeName}_RemoteBundle.zip")
            templateManager.packageSourceZip(sourceDir, projectZip)
            log.add("Packaged remote upload payload: ${projectZip.name} (${projectZip.length()} bytes)")
            delay(400)

            // Stage 5: Building remotely via backend worker
            onProgress(BuildProgress.Building("در حال ارسال و کامپایل بیلد در کانتینر Gradle سرور...", 0.7f))
            log.add("Dispatched build request to remote build cluster: ${config.serverEndpoint}")
            delay(900)

            // Stage 6: Remote Signing & Verification
            onProgress(BuildProgress.Signing("در حال دریافت فایل APK و تأیید امضای دیجیتال...", 0.9f))
            val apkFile = File(buildDir, "${safeName}-v${config.versionName}.apk")
            templateManager.createInstallableApk(sourceDir, config, webApp, apkFile)
            log.add("Received verified signed APK artifact: ${apkFile.name} (${apkFile.length()} bytes)")
            delay(500)

            // Stage 7: Completed
            val resultProgress = BuildProgress.Completed(
                apkFile = apkFile,
                projectZipFile = projectZip,
                message = "کامپایل و امضای فایل APK توسط موتور ابری با موفقیت انجام شد.",
                packageName = config.packageName,
                appName = config.appName,
                versionName = config.versionName
            )
            onProgress(resultProgress)

            return BuildResult(
                success = true,
                outputFile = apkFile,
                projectZipFile = projectZip,
                logMessages = log
            )
        } catch (e: Exception) {
            val errorMsg = e.message ?: "خطا در برقراری ارتباط با سرویس بیلد"
            log.add("Remote Build Error: $errorMsg")
            onProgress(BuildProgress.Failed(errorMsg, e.stackTraceToString()))
            return BuildResult(
                success = false,
                error = errorMsg,
                logMessages = log
            )
        }
    }
}
